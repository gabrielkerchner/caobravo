import pymysql

pymysql.install_as_MySQLdb()

# -*- coding: utf 8 -*-

import sys
reload(sys)
sys.setdefaultencoding("utf-8")